from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
import json

ROOT=Path('/workspace/work/powersports')
scene=Image.open(ROOT/'a.png').convert('RGB')
logo=Image.open(ROOT/'c.png').convert('RGBA')
W,H=1672,1750
HEADER=150
out=Image.new('RGB',(W,H),(8,8,8))
out.paste(scene,(0,HEADER))
d=ImageDraw.Draw(out)
lime='#BFF803';white='#EEEEEC';gray='#A4A7A7'
fontroot='/usr/share/fonts/truetype/dejavu/'
def font(size,bold=False):
 return ImageFont.truetype(fontroot+('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'),size)
def text(x,y,value,size=24,color=white,bold=False):
 d.text((x,y),value,font=font(size,bold),fill=color)
def right(value,y,rightedge,size,color=white,bold=False):
 f=font(size,bold);width=d.textlength(value,font=f)
 d.text((rightedge-width,y),value,font=f,fill=color)

# Geometric support masks select only the original emblem and wordmark.
# No font substitution, redraw or modification of source RGB.
support=Image.new('L',logo.size,0);md=ImageDraw.Draw(support)
md.ellipse((330,225,930,750),fill=255)
support=support.filter(ImageFilter.GaussianBlur(12))
for y in range(235,745):
 for x in range(330,925):
  r,g,b=logo.getpixel((x,y))[:3]
  if max(r,g,b)>=65 or (g-r>=5 and g-b>=8):support.putpixel((x,y),255)
emblem=logo.copy();emblem.putalpha(support)
emblem=emblem.crop((320,215,940,760)).resize((111,98),Image.Resampling.LANCZOS)
out.paste(emblem,(76,25),emblem)
word=logo.crop((94,817,1161,906))
alpha=Image.new('L',word.size,0)
for y in range(word.height):
 for x in range(word.width):
  v=max(word.getpixel((x,y))[:3])
  alpha.putpixel((x,y),255 if v>=24 else round(max(0,(v-5)/19)*255))
word.putalpha(alpha)
word=word.resize((475,40),Image.Resampling.LANCZOS)
out.paste(word,(207,54),word)
d=ImageDraw.Draw(out)
right('КОРЗИНА',58,1592,25)
right('OEM +',58,1365,25,lime,True)
right('LIFE',58,1180,25)
d.line((0,149,W,149),fill='#363A3A')
right('POWERSPORTS',HEADER+53,1592,65,white,True)
right('MACHINE',HEADER+132,1592,33,lime)

# Free floor area only: the table/stool starts to the right of x=1180.
sy=HEADER+781
d.rounded_rectangle((80,sy,765,sy+81),radius=9,fill=(18,19,19),outline='#CACDCC',width=2)
text(106,sy+23,'Введи',28,lime,True)
text(213,sy+24,'каталожный номер',27)
d.rounded_rectangle((787,sy,1120,sy+81),radius=9,fill=(18,19,19),outline='#CACDCC',width=2)
d.ellipse((811,sy+25,834,sy+48),outline=lime,width=3)
d.line((831,sy+46,845,sy+60),fill=lime,width=3)
text(863,sy+27,'Поиск по номеру',21,white,True)
for x,s in [(80,'Оригинальные запчасти'),(373,'Проверенные аналоги'),(665,'Наличие в РФ'),(891,'Цены под заказ')]:
 text(x,sy+105,s,18,white)

top=HEADER+scene.height
text(80,top+42,'Техника должна ехать.',49)
d.line((80,top+125,1592,top+125),fill='#555B5B')
text(80,top+177,'ПРАКТИКА ВЛАДЕНИЯ',32,white,True)
gap=24;cw=488;cy=top+241
for i,title in enumerate(['ОБСЛУЖИВАНИЕ','ЭКСПЛУАТАЦИЯ','ПОДГОТОВКА']):
 x=80+i*(cw+gap)
 d.rounded_rectangle((x,cy,x+cw,cy+184),radius=8,fill='#101313',outline='#59605F',width=1)
 text(x+28,cy+22,f'0{i+1}',27,lime,True)
 text(x+28,cy+65,title,27,white,True)
 text(x+28,cy+121,'Раздел будущих материалов',21,gray)
 d.line((x+cw-64,cy+78,x+cw-34,cy+78),fill=white,width=2)
 d.line((x+cw-44,cy+68,x+cw-34,cy+78,x+cw-44,cy+88),fill=white,width=2)
d.line((80,top+479,1592,top+479),fill='#555B5B')
text(80,top+524,'ДРУГИЕ НАПРАВЛЕНИЯ',23,white,True)
text(438,top+524,'LIFE',23,lime,True)
for x,label in [(559,'WORKOUT & GYM'),(828,'FOOD & HEALTH'),(1084,'OUTDOOR & TRAVEL'),(1390,'GET TOGETHER')]:
 text(x,top+528,label,17)
 if x!=1390:text(x+230,top+526,'/',21,lime)

out.save(ROOT/'EXTREMIZER_POWERSPORTS.png')
# Exact comparison: no color grade/resize/crop; only declared UI overlays.
hero=out.crop((0,HEADER,W,HEADER+scene.height))
delta=ImageChops.difference(scene,hero)
allowed=Image.new('L',scene.size,0);ad=ImageDraw.Draw(allowed)
ad.rectangle((860,45,1600,182),fill=255)
ad.rectangle((75,775,1125,921),fill=255)
outside=ImageChops.multiply(delta,Image.merge('RGB',(ImageChops.invert(allowed),)*3))
assert outside.getbbox() is None
table_box=(1180,390,1672,941)
assert scene.crop(table_box).tobytes()==hero.crop(table_box).tobytes()
hero.crop(table_box).save(ROOT/'table_verified.png')
out.crop((65,15,700,130)).save(ROOT/'logo_header.png')
report={'source_A_size':scene.size,'canvas_size':out.size,'scene_origin':[0,HEADER],
 'scene_resized':False,'scene_cropped':False,'outside_UI_changed_pixels':0,
 'table_crop':table_box,'table_pixels_equal':True,
 'logo_source':'c.png; original emblem/wordmark extracted via alpha masks',
 'UI_source':'Redrawn from B composition using PIL; no pixels pasted from B',
 'generation_used':False}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
